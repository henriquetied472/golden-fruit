mkdir ~/.goldenfruit
sudo mv Roboto-Regular.ttf ~/.goldenfruit/Roboto-Regular.ttf
sudo mv golden-fruit ~/.goldenfruit/golden-fruit
sudo ln ~/.goldenfruit/golden-fruit /usr/bin/golden-fruit